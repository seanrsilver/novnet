#' functionName()
#'
#' description
#'
#' @param argument Description ends with .
#' @keywords NovNet Utilities
#'
#'
#' @export
